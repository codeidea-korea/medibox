$(function(){
// ------------------------------------

    //-------------- pointhome.html 1차 탭메뉴

    // const pointMenu = $('#point_tab_menu>ul>li');
    // const firstTarget = pointMenu.eq(0);
    
    // firstTarget.addClass('on');
    // firstTarget.addClass('highlight');

    // pointMenu.on('click', function(){
    //     $(this).addClass('on').siblings().removeClass('on');
    //     $(this).addClass('highlight').siblings().removeClass('highlight');

    //     // 탭메뉴 filter
    //     $('#point_payment>div').hide();
    //     if (pointMenu.eq(0).hasClass('on')) {
    //         $('#point_payment>div').show();
    //     } else if (pointMenu.eq(1).hasClass('on')) {
    //         $('.my_point_wrap').show();
    //     } else if (pointMenu.eq(2).hasClass('on')) {
    //         $('.my_pass_wrap').show();
    //     };
    // });


    // ------------- pointhome.html 2차 탭메뉴

    const paymentMenu = $('#point_tab_menu>ul>li');
    const firstTarget = paymentMenu.eq(0);
    
    firstTarget.addClass('on');

    $('#point_payment>div').hide();
    $('#point_payment>div').eq(0).show();
    paymentMenu.on('click', function(){
        let menuIndex = $(this).index();

        $(this).addClass('on').siblings().removeClass('on');

        // 탭메뉴 filter
        $('#point_payment>div').hide();
        $('#point_payment>div').eq(menuIndex).show();
    });


    // -------------------------------------


    const tabMenu = $('.tab_menu>li');
    const tabContent = $('.tab_content');

    tabContent.hide();
    tabContent.eq(0).show();
    tabMenu.on('click', function(){
        let idx = $(this).index();

        $(this).addClass('on').siblings().removeClass('on');

        tabContent.hide();
        tabContent.eq(idx).show();
    });
// ------------------------------------
});